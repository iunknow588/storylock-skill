Option Explicit

Dim shell
Dim fso
Dim scriptDir
Dim hostExe

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
hostExe = fso.BuildPath(scriptDir, "yian-windows-host.exe")

If Not fso.FileExists(hostExe) Then
  MsgBox "yian-windows-host.exe was not found next to this launcher. Please extract the full zip package first.", 16, "Yian Windows Host"
  WScript.Quit 1
End If

If shell.ExpandEnvironmentStrings("%STORYLOCK_GATEWAY_URL%") = "%STORYLOCK_GATEWAY_URL%" Then
  shell.Environment("PROCESS")("STORYLOCK_GATEWAY_URL") = "https://yian.cdao.online"
End If

shell.Run """" & hostExe & """ --tray", 0, False
