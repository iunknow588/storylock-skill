# Yian Windows Host

This directory is the Windows desktop local host skeleton for Yian / StoryLock.

Recommended implementation language: Rust.

Why Rust for Windows:

1. produces a direct-run `.exe`, `.msi`, or `.zip` package for regular users
2. avoids requiring Python or a separate runtime on the user's machine
3. fits a long-running local host with localhost HTTP, relay polling, tray integration, and Windows credential APIs
4. can integrate with Windows Credential Manager or DPAPI for local secret protection

Current scope in this directory:

1. Rust project skeleton
2. default Windows host configuration
3. shared registration / relay contract notes
4. local `GET /health` and `POST /execute` HTTP endpoints
5. gateway registration and relay polling prototype
6. placeholder execution response that does not perform production approval yet

Target runtime flow:

1. Yian website exposes `/app/download/windows`
2. user downloads and runs the Windows package
3. Windows host registers with the remote gateway using relay mode
4. Windows host polls relay requests and executes local approvals
5. StoryLock Local Core remains local and returns minimal results through the private assistant

Default ports and endpoints:

1. local health: `http://127.0.0.1:4510/health`
2. local execute: `http://127.0.0.1:4510/execute`
3. gateway register: `/android-host/register` for compatibility in the first phase
4. relay poll: `/android-host/relay/poll`
5. relay respond: `/android-host/relay/respond`

Build:

```powershell
cargo build --release
```

Print config only:

```powershell
cargo run -- --print-config
```

Run prototype:

```powershell
$env:STORYLOCK_GATEWAY_URL="https://yian.cdao.online"
$env:STORYLOCK_ANDROID_SHARED_SECRET="replace-with-strong-shared-secret"
cargo run
```

Package:

```powershell
..\scripts\windows\build_windows_host.cmd
```

Future package names:

1. `yian-windows-host-0.1.0-1-prototype.zip`
2. `yian-windows-host-0.1.0-1.exe`
3. `yian-windows-host-0.1.0-1.msi`

Important limitation:

The current Rust host is a prototype. It can register, expose health, poll relay requests, and submit placeholder responses. It does not yet implement production local approval, Windows Credential Manager / DPAPI storage, tray UI, installer signing, or local StoryLock Core execution.

Distribution environment variables:

1. `STORYLOCK_WINDOWS_PACKAGE_PATH`
2. `STORYLOCK_WINDOWS_APP_DOWNLOAD_URL`
3. `STORYLOCK_WINDOWS_PACKAGE_VERSION`
4. `STORYLOCK_WINDOWS_PACKAGE_VERSION_CODE`
5. `STORYLOCK_WINDOWS_PACKAGE_SIZE_BYTES`
6. `STORYLOCK_WINDOWS_PACKAGE_CHECKSUM`
7. `STORYLOCK_WINDOWS_PACKAGE_KIND`
8. `STORYLOCK_WINDOWS_RELEASE_CHANNEL`
