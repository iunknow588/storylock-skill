# Yian Linux Host Package

Prototype package generated from the StoryLock workspace.

Run:

```bash
node src/host/linux-host/server.mjs
```

Self-check from the full workspace:

```bash
npm run test:linux-host
```

Production-mode start:

```bash
STORYLOCK_LINUX_USE_PLATFORM_SECRET_STORE=1 STORYLOCK_LINUX_DEVELOPMENT_MODE=0 ./src/host/linux-host/bin/yian-linux-host
```
